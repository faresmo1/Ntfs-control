package com.otgfiles

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import com.otgfiles.fs.FsBackend
import com.otgfiles.fs.LocalBackend
import com.otgfiles.fs.NtfsBackend
import com.otgfiles.usb.CachedDevice
import com.otgfiles.usb.FsType
import com.otgfiles.usb.PartitionDevice
import com.otgfiles.usb.PartitionScanner
import com.otgfiles.usb.UsbMassStorage
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/** Finds every storage the app can browse: internal, Android-mounted volumes, and NTFS over raw USB. */
class StorageHub(private val app: Context) {

    private val usb = app.getSystemService(Context.USB_SERVICE) as UsbManager
    private val sm = app.getSystemService(Context.STORAGE_SERVICE) as StorageManager

    private val _backends = MutableStateFlow<List<FsBackend>>(emptyList())
    val backends: StateFlow<List<FsBackend>> = _backends

    private val _usbDevices = MutableStateFlow<List<UsbDevice>>(emptyList())
    val usbDevices: StateFlow<List<UsbDevice>> = _usbDevices

    /** device name -> (raw device, backends mounted from it) */
    private val mounted = HashMap<String, Pair<UsbMassStorage, List<NtfsBackend>>>()
    private var permWaiter: CompletableDeferred<Boolean>? = null

    var readOnlyMount = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACTION_PERM -> permWaiter?.complete(i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    val d = usbDeviceOf(i)
                    if (d != null) dropDevice(d.deviceName)
                    refresh()
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED,
                Intent.ACTION_MEDIA_MOUNTED, Intent.ACTION_MEDIA_UNMOUNTED,
                Intent.ACTION_MEDIA_EJECT, Intent.ACTION_MEDIA_REMOVED -> refresh()
            }
        }
    }

    init {
        val f = IntentFilter().apply {
            addAction(ACTION_PERM)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(Intent.ACTION_MEDIA_MOUNTED); addAction(Intent.ACTION_MEDIA_UNMOUNTED)
            addAction(Intent.ACTION_MEDIA_EJECT); addAction(Intent.ACTION_MEDIA_REMOVED)
            addDataScheme("file")
        }
        // media actions need the "file" data scheme, USB ones don't: register twice
        val usbOnly = IntentFilter().apply {
            addAction(ACTION_PERM)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        val flag = if (Build.VERSION.SDK_INT >= 33) Context.RECEIVER_NOT_EXPORTED else 0
        app.registerReceiver(receiver, usbOnly, flag)
        app.registerReceiver(receiver, f, flag)
        refresh()
    }

    @Suppress("DEPRECATION")
    private fun usbDeviceOf(i: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        else i.getParcelableExtra(UsbManager.EXTRA_DEVICE)

    fun hasAllFilesAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    fun refresh() {
        val list = mutableListOf<FsBackend>()
        if (hasAllFilesAccess()) {
            list += LocalBackend("internal", "Internal storage", Environment.getExternalStorageDirectory())
            for (v in sm.storageVolumes) {
                if (v.isPrimary || v.state != Environment.MEDIA_MOUNTED) continue
                val dir: File = if (Build.VERSION.SDK_INT >= 30) v.directory ?: continue else continue
                list += LocalBackend("vol-${v.uuid}", v.getDescription(app) ?: "USB drive", dir)
            }
        }
        synchronized(mounted) { mounted.values.forEach { list += it.second } }
        _backends.value = list
        _usbDevices.value = usb.deviceList.values.filter { isMassStorage(it) }
    }

    private fun isMassStorage(d: UsbDevice): Boolean =
        (0 until d.interfaceCount).any {
            val i = d.getInterface(it)
            i.interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE && i.interfaceSubclass == 6 && i.interfaceProtocol == 80
        }

    fun isMounted(d: UsbDevice) = synchronized(mounted) { mounted.containsKey(d.deviceName) }

    /** Asks for permission, then reads the partition table and mounts every NTFS partition with ntfs-3g. */
    suspend fun mountNtfs(d: UsbDevice): String = withContext(Dispatchers.IO) {
        if (!usb.hasPermission(d)) {
            val w = CompletableDeferred<Boolean>().also { permWaiter = it }
            val pi = PendingIntent.getBroadcast(
                app, 0, Intent(ACTION_PERM).setPackage(app.packageName),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            usb.requestPermission(d, pi)
            if (!w.await()) throw IOException("تم رفض صلاحية USB")
        }
        val raw = UsbMassStorage(usb, d)
        raw.open()
        val cached = CachedDevice(raw)
        val parts = try { PartitionScanner.scan(cached).filter { it.fsType == FsType.NTFS } }
        catch (e: Exception) { raw.close(); throw e }
        if (parts.isEmpty()) {
            raw.close()
            throw IOException("مفيش بارتيشن NTFS على الجهاز ده. FAT32/exFAT أندرويد بيفتحهم لوحده من القسم العادي.")
        }
        val made = ArrayList<NtfsBackend>()
        try {
            for (p in parts) {
                val title = "${raw.label} #${p.index + 1}"
                made += NtfsBackend(
                    "ntfs-${d.deviceName}-${p.index}", title,
                    PartitionDevice(cached, p.startBytes, p.sizeBytes), readOnlyMount,
                )
            }
        } catch (e: Exception) {
            made.forEach { it.close() }; raw.close(); throw e
        }
        synchronized(mounted) { mounted[d.deviceName] = raw to made }
        refresh()
        "تم تحميل ${made.size} بارتيشن NTFS"
    }

    /** Flushes and releases. Always do this before pulling the cable. */
    suspend fun eject(d: UsbDevice) = withContext(Dispatchers.IO) { dropDevice(d.deviceName); refresh() }

    private fun dropDevice(name: String) {
        val entry = synchronized(mounted) { mounted.remove(name) } ?: return
        entry.second.forEach { runCatching { it.close() } }
        runCatching { entry.first.flush() }
        runCatching { entry.first.close() }
    }

    fun release() {
        runCatching { app.unregisterReceiver(receiver) }
        synchronized(mounted) { mounted.keys.toList() }.forEach(::dropDevice)
    }

    companion object { const val ACTION_PERM = "com.otgfiles.USB_PERMISSION" }
}

package com.otgfiles.usb

import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** A window [start, start+size) over another device. */
class PartitionDevice(
    private val base: BlockDevice,
    val start: Long,
    override val sizeBytes: Long,
) : BlockDevice {
    override fun read(offset: Long, buf: ByteArray, len: Int): Int {
        if (offset < 0 || offset + len > sizeBytes) throw IOException("Read outside partition")
        return base.read(start + offset, buf, len)
    }
    override fun write(offset: Long, buf: ByteArray, len: Int): Int {
        if (offset < 0 || offset + len > sizeBytes) throw IOException("Write outside partition")
        return base.write(start + offset, buf, len)
    }
    override fun flush() = base.flush()
}

/**
 * Read-ahead cache. NTFS driver issues many small reads; the USB layer is much faster
 * with big aligned transfers. Writes are write-through, so nothing is lost on unplug
 * (apart from what the drive itself has cached).
 */
class CachedDevice(private val base: BlockDevice) : BlockDevice {
    override val sizeBytes get() = base.sizeBytes
    private val page = 128 * 1024
    private val maxPages = 32
    private val cache = object : LinkedHashMap<Long, ByteArray>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<Long, ByteArray>?) = size > maxPages
    }

    @Synchronized
    override fun read(offset: Long, buf: ByteArray, len: Int): Int {
        var pos = offset
        var dst = 0
        while (dst < len) {
            val idx = pos / page
            val data = cache.getOrPut(idx) {
                val start = idx * page
                val n = minOf(page.toLong(), base.sizeBytes - start).toInt()
                ByteArray(n).also { base.read(start, it, n) }
            }
            val inPage = (pos - idx * page).toInt()
            val copy = minOf(len - dst, data.size - inPage)
            if (copy <= 0) throw IOException("Read past end")
            System.arraycopy(data, inPage, buf, dst, copy)
            dst += copy; pos += copy
        }
        return len
    }

    @Synchronized
    override fun write(offset: Long, buf: ByteArray, len: Int): Int {
        base.write(offset, buf, len)
        // keep cache coherent: update pages that are cached
        var pos = offset
        var src = 0
        while (src < len) {
            val idx = pos / page
            val inPage = (pos - idx * page).toInt()
            val n = minOf(len - src, page - inPage)
            cache[idx]?.let { if (inPage + n <= it.size) System.arraycopy(buf, src, it, inPage, n) else cache.remove(idx) }
            src += n; pos += n
        }
        return len
    }

    @Synchronized
    override fun flush() = base.flush()
}

data class PartitionInfo(
    val index: Int,
    val startBytes: Long,
    val sizeBytes: Long,
    val fsType: FsType,
)

enum class FsType { NTFS, FAT, EXFAT, UNKNOWN }

object PartitionScanner {

    fun scan(dev: BlockDevice): List<PartitionInfo> {
        val sector0 = ByteArray(512).also { dev.read(0, it, 512) }
        val bb0 = ByteBuffer.wrap(sector0).order(ByteOrder.LITTLE_ENDIAN)
        val sig = bb0.getShort(510).toInt() and 0xFFFF
        val result = mutableListOf<PartitionInfo>()

        // Whole disk formatted without partition table ("superfloppy")
        val direct = detectFs(sector0)
        if (direct != FsType.UNKNOWN) {
            return listOf(PartitionInfo(0, 0, dev.sizeBytes, direct))
        }
        if (sig != 0xAA55) return emptyList()

        val isGpt = (0 until 4).any { (sector0[446 + it * 16 + 4].toInt() and 0xFF) == 0xEE }
        if (isGpt) {
            val hdr = ByteArray(512).also { dev.read(512, it, 512) }
            val h = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN)
            if (String(hdr, 0, 8, Charsets.US_ASCII) == "EFI PART") {
                val entriesLba = h.getLong(72)
                val count = h.getInt(80)
                val size = h.getInt(84)
                val table = ByteArray(count * size).also { dev.read(entriesLba * 512, it, it.size) }
                val t = ByteBuffer.wrap(table).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until count) {
                    val o = i * size
                    // all-zero type GUID = unused
                    if ((0 until 16).all { table[o + it].toInt() == 0 }) continue
                    val first = t.getLong(o + 32)
                    val last = t.getLong(o + 40)
                    addIfKnown(dev, result, i, first * 512, (last - first + 1) * 512)
                }
                return result
            }
        }
        for (i in 0 until 4) {
            val o = 446 + i * 16
            val type = sector0[o + 4].toInt() and 0xFF
            if (type == 0) continue
            val lba = bb0.getInt(o + 8).toLong() and 0xFFFFFFFFL
            val cnt = bb0.getInt(o + 12).toLong() and 0xFFFFFFFFL
            if (type == 0x05 || type == 0x0F) continue // extended: not handled
            addIfKnown(dev, result, i, lba * 512, cnt * 512)
        }
        return result
    }

    private fun addIfKnown(dev: BlockDevice, out: MutableList<PartitionInfo>, i: Int, start: Long, size: Long) {
        if (start < 0 || size <= 0 || start + size > dev.sizeBytes) return
        val boot = ByteArray(512)
        try { dev.read(start, boot, 512) } catch (_: IOException) { return }
        val fs = detectFs(boot)
        if (fs != FsType.UNKNOWN) out += PartitionInfo(i, start, size, fs)
    }

    private fun detectFs(boot: ByteArray): FsType {
        fun at(off: Int, s: String) = String(boot, off, s.length, Charsets.US_ASCII) == s
        return when {
            at(3, "NTFS    ") -> FsType.NTFS
            at(3, "EXFAT   ") -> FsType.EXFAT
            at(82, "FAT32   ") || at(54, "FAT16   ") || at(54, "FAT12   ") -> FsType.FAT
            else -> FsType.UNKNOWN
        }
    }
}

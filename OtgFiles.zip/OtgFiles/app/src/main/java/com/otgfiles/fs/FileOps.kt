package com.otgfiles.fs

import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext
import java.io.IOException
import java.io.InputStream

class Progress(var totalBytes: Long = 0, var doneBytes: Long = 0, var current: String = "")

object FileOps {

    private const val BUF = 256 * 1024

    /** Returns a free name inside [dir]: "a.txt", "a (1).txt", "a (2).txt" ... */
    fun uniqueName(b: FsBackend, dir: String, name: String): String {
        val existing = b.list(dir).map { it.name.lowercase() }.toSet()
        if (name.lowercase() !in existing) return name
        val dot = name.lastIndexOf('.').takeIf { it > 0 } ?: name.length
        val base = name.substring(0, dot)
        val ext = name.substring(dot)
        var i = 1
        while ("$base ($i)$ext".lowercase() in existing) i++
        return "$base ($i)$ext"
    }

    fun sizeOf(b: FsBackend, e: FsEntry): Long =
        if (!e.isDir) e.size else b.list(e.path).sumOf { sizeOf(b, it) }

    suspend fun copy(
        src: FsBackend, srcEntry: FsEntry,
        dst: FsBackend, dstDir: String,
        p: Progress,
    ) {
        coroutineContext.ensureActive()
        // never copy a folder into itself
        if (src === dst && srcEntry.isDir &&
            (dstDir == srcEntry.path || dstDir.startsWith(srcEntry.path + "/"))
        ) throw IOException("مينفعش تنسخ فولدر جوه نفسه")

        val name = uniqueName(dst, dstDir, srcEntry.name)
        val target = joinPath(dstDir, name)
        p.current = srcEntry.name
        if (srcEntry.isDir) {
            dst.mkdir(target)
            for (child in src.list(srcEntry.path)) copy(src, child, dst, target, p)
        } else {
            src.openRead(srcEntry.path).use { input ->
                dst.openWrite(target).use { out ->
                    val buf = ByteArray(BUF)
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        p.doneBytes += n
                    }
                }
            }
        }
    }

    suspend fun copyStreamInto(
        input: InputStream, dst: FsBackend, dstDir: String, name: String, size: Long, p: Progress,
    ) {
        val target = joinPath(dstDir, uniqueName(dst, dstDir, name))
        p.current = name
        input.use { ins ->
            dst.openWrite(target).use { out ->
                val buf = ByteArray(BUF)
                while (true) {
                    coroutineContext.ensureActive()
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    p.doneBytes += n
                }
            }
        }
    }

    /** Same backend: cheap rename. Different backend: copy, then delete the source. */
    suspend fun move(
        src: FsBackend, srcEntry: FsEntry, dst: FsBackend, dstDir: String, p: Progress,
    ) {
        if (src === dst) {
            if (parentOf(srcEntry.path) == dstDir) return
            if (srcEntry.isDir && (dstDir == srcEntry.path || dstDir.startsWith(srcEntry.path + "/")))
                throw IOException("مينفعش تنقل فولدر جوه نفسه")
            val name = uniqueName(dst, dstDir, srcEntry.name)
            p.current = srcEntry.name
            src.rename(srcEntry.path, joinPath(dstDir, name))
            p.doneBytes += if (srcEntry.isDir) 0 else srcEntry.size
        } else {
            copy(src, srcEntry, dst, dstDir, p)
            src.delete(srcEntry.path)
        }
    }
}

package com.otgfiles.fs

import com.otgfiles.usb.BlockDevice
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * NTFS volume driven by libntfs-3g (native, userspace) on top of a BlockDevice.
 * ntfs-3g is not thread-safe, so every native call goes through [lock].
 */
class NtfsBackend(
    override val id: String,
    override val title: String,
    private val dev: BlockDevice,
    readOnly: Boolean,
) : FsBackend {

    private val lock = Any()
    private fun b(p: String) = p.toByteArray(Charsets.UTF_8)
    private var vol: Long = 0
    override var writable: Boolean = !readOnly
        private set

    /** Called from C. Returns bytes read or -1. */
    @Suppress("unused")
    fun devRead(offset: Long, buf: ByteArray, len: Int): Int =
        try { dev.read(offset, buf, len) } catch (e: Exception) { -1 }

    /** Called from C. Returns bytes written or -1. */
    @Suppress("unused")
    fun devWrite(offset: Long, buf: ByteArray, len: Int): Int =
        try { dev.write(offset, buf, len) } catch (e: Exception) { -1 }

    init {
        val r = nativeMount(this, dev.sizeBytes, readOnly)
        if (r <= 0) {
            throw IOException(
                when (r.toInt()) {
                    -1 -> "NTFS غير نظيف (Windows Fast Startup أو إخراج غير آمن). افصله من الكمبيوتر بشكل صحيح أو شغّل chkdsk."
                    -2 -> "الهارد في وضع hibernate من ويندوز، عطّل Fast Startup."
                    else -> "فشل تحميل NTFS (code $r)"
                }
            )
        }
        vol = r
    }

    override val totalBytes get() = synchronized(lock) { nativeTotal(vol) }
    override val freeBytes get() = synchronized(lock) { nativeFree(vol) }

    override fun list(path: String): List<FsEntry> = synchronized(lock) {
        val raw = nativeList(vol, b(path)) ?: throw IOException("Cannot list $path")
        // each item: name US isDir(0/1) US size US modifiedMillis  (US = \u001F)
        raw.map {
            val p = it.split('\u001F')
            FsEntry(p[0], joinPath(path, p[0]), p[1] == "1", p[2].toLong(), p[3].toLong())
        }
    }

    override fun stat(path: String): FsEntry? = synchronized(lock) {
        val s = nativeStat(vol, b(path)) ?: return null
        val p = s.split('\u001F')
        FsEntry(nameOf(path).ifEmpty { "/" }, path, p[0] == "1", p[1].toLong(), p[2].toLong())
    }

    private fun checkWritable() { if (!writable) throw IOException("Volume is read-only") }
    private fun chk(rc: Int, what: String) { if (rc != 0) throw IOException("$what failed (errno ${-rc})") }

    override fun mkdir(path: String) = synchronized(lock) { checkWritable(); chk(nativeCreate(vol, b(path), true), "mkdir") }
    override fun createFile(path: String) = synchronized(lock) { checkWritable(); chk(nativeCreate(vol, b(path), false), "create") }
    override fun delete(path: String) = synchronized(lock) { checkWritable(); deleteRec(path) }

    private fun deleteRec(path: String) {
        val st = stat(path) ?: return
        if (st.isDir) list(path).forEach { deleteRec(it.path) }
        chk(nativeUnlink(vol, b(path)), "delete")
    }

    override fun rename(from: String, to: String) =
        synchronized(lock) { checkWritable(); chk(nativeRename(vol, b(from), b(to)), "rename") }

    override fun openRead(path: String): InputStream {
        val h = synchronized(lock) { nativeOpen(vol, b(path), false, false) }
        if (h <= 0) throw IOException("open failed")
        return object : InputStream() {
            var pos = 0L
            var closed = false
            override fun read(): Int { val b = ByteArray(1); return if (read(b, 0, 1) <= 0) -1 else b[0].toInt() and 0xFF }
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (len == 0) return 0
                val tmp = if (off == 0) b else ByteArray(len)
                val n = synchronized(lock) { nativeRead(h, pos, tmp, len) }
                if (n < 0) throw IOException("read error")
                if (n == 0) return -1
                if (off != 0) System.arraycopy(tmp, 0, b, off, n)
                pos += n
                return n
            }
            override fun close() { if (!closed) { closed = true; synchronized(lock) { nativeClose(h) } } }
        }
    }

    override fun openWrite(path: String, append: Boolean): OutputStream {
        synchronized(lock) { checkWritable() }
        val h = synchronized(lock) { nativeOpen(vol, b(path), true, !append) }
        if (h <= 0) throw IOException("open for write failed")
        var pos = if (append) (stat(path)?.size ?: 0L) else 0L
        return object : OutputStream() {
            var closed = false
            override fun write(b: Int) = write(byteArrayOf(b.toByte()), 0, 1)
            override fun write(b: ByteArray, off: Int, len: Int) {
                val tmp = if (off == 0) b else b.copyOfRange(off, off + len)
                var done = 0
                while (done < len) {
                    val src = if (done == 0) tmp else tmp.copyOfRange(done, len)
                    val n = synchronized(lock) { nativeWrite(h, pos, src, len - done) }
                    if (n <= 0) throw IOException("write error (disk full?)")
                    done += n; pos += n
                }
            }
            override fun close() { if (!closed) { closed = true; synchronized(lock) { nativeClose(h) } } }
        }
    }

    override fun close() = synchronized(lock) {
        if (vol != 0L) { nativeUnmount(vol); vol = 0 }
        dev.flush()
    }

    private external fun nativeMount(self: NtfsBackend, size: Long, readOnly: Boolean): Long
    private external fun nativeUnmount(vol: Long)
    private external fun nativeTotal(vol: Long): Long
    private external fun nativeFree(vol: Long): Long
    private external fun nativeList(vol: Long, path: ByteArray): Array<String>?
    private external fun nativeStat(vol: Long, path: ByteArray): String?
    private external fun nativeCreate(vol: Long, path: ByteArray, dir: Boolean): Int
    private external fun nativeUnlink(vol: Long, path: ByteArray): Int
    private external fun nativeRename(vol: Long, from: ByteArray, to: ByteArray): Int
    private external fun nativeOpen(vol: Long, path: ByteArray, write: Boolean, truncate: Boolean): Long
    private external fun nativeRead(h: Long, offset: Long, buf: ByteArray, len: Int): Int
    private external fun nativeWrite(h: Long, offset: Long, buf: ByteArray, len: Int): Int
    private external fun nativeClose(h: Long)

    companion object {
        init { System.loadLibrary("ntfsjni") }
    }
}

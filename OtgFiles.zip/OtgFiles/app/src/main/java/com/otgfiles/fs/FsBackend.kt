package com.otgfiles.fs

import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile

data class FsEntry(
    val name: String,
    val path: String,      // absolute path inside the backend, "/" is root
    val isDir: Boolean,
    val size: Long,
    val modified: Long,    // epoch millis
)

/** One mounted storage (internal storage, an SD/FAT/exFAT volume, or an NTFS partition over USB). */
interface FsBackend {
    val id: String
    val title: String
    val totalBytes: Long
    val freeBytes: Long
    val writable: Boolean

    fun list(path: String): List<FsEntry>
    fun stat(path: String): FsEntry?
    fun mkdir(path: String)
    fun createFile(path: String)
    fun delete(path: String)                 // files and (recursively) folders
    fun rename(from: String, to: String)
    fun openRead(path: String): InputStream
    fun openWrite(path: String, append: Boolean = false): OutputStream
    fun close() {}
}

fun joinPath(dir: String, name: String) = if (dir == "/") "/$name" else "$dir/$name"
fun parentOf(path: String): String = path.substringBeforeLast('/', "").ifEmpty { "/" }
fun nameOf(path: String): String = path.substringAfterLast('/')

/** java.io.File backed storage: internal memory and anything Android mounted itself (FAT32/exFAT/SD). */
class LocalBackend(
    override val id: String,
    override val title: String,
    private val root: File,
) : FsBackend {
    override val totalBytes get() = root.totalSpace
    override val freeBytes get() = root.usableSpace
    override val writable get() = root.canWrite()

    private fun f(path: String) = if (path == "/") root else File(root, path.trimStart('/'))

    private fun toEntry(file: File) = FsEntry(
        file.name,
        "/" + file.relativeTo(root).path.replace(File.separatorChar, '/'),
        file.isDirectory, if (file.isDirectory) 0 else file.length(), file.lastModified(),
    )

    override fun list(path: String): List<FsEntry> =
        f(path).listFiles()?.map(::toEntry) ?: throw IOException("Cannot list $path")

    override fun stat(path: String) = f(path).takeIf { it.exists() }?.let(::toEntry)
    override fun mkdir(path: String) { if (!f(path).mkdirs()) throw IOException("mkdir failed") }
    override fun createFile(path: String) { if (!f(path).createNewFile()) throw IOException("create failed") }
    override fun delete(path: String) { if (!f(path).deleteRecursively()) throw IOException("delete failed") }
    override fun rename(from: String, to: String) { if (!f(from).renameTo(f(to))) throw IOException("rename failed") }
    override fun openRead(path: String): InputStream = f(path).inputStream()
    override fun openWrite(path: String, append: Boolean): OutputStream = java.io.FileOutputStream(f(path), append)
}

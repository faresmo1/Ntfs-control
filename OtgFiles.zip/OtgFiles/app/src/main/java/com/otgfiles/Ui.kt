@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.otgfiles

import android.hardware.usb.UsbDevice
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.otgfiles.fs.FsBackend
import com.otgfiles.fs.FsEntry
import com.otgfiles.fs.nameOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmtSize(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB")
    var v = b.toDouble(); var i = -1
    while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
    return String.format(Locale.US, "%.1f %s", v, u[i])
}

private val dateFmt = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
private fun fmtDate(ms: Long) = if (ms <= 0) "" else dateFmt.format(Date(ms))

private fun iconFor(e: FsEntry): Pair<ImageVector, Color> {
    if (e.isDir) return Icons.Filled.Folder to Color(0xFFFFB300)
    return when (e.name.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> Icons.Filled.Image to Color(0xFF43A047)
        "mp4", "mkv", "avi", "mov", "webm", "3gp" -> Icons.Filled.VideoFile to Color(0xFFE53935)
        "mp3", "wav", "flac", "m4a", "ogg", "aac" -> Icons.Filled.AudioFile to Color(0xFF8E24AA)
        "pdf" -> Icons.Filled.PictureAsPdf to Color(0xFFD32F2F)
        "zip", "rar", "7z", "tar", "gz" -> Icons.Filled.FolderZip to Color(0xFF6D4C41)
        "txt", "md", "log", "json", "xml", "csv", "ini", "html", "css", "js", "kt", "java", "py" ->
            Icons.Filled.Description to Color(0xFF1E88E5)
        else -> Icons.Filled.InsertDriveFile to Color(0xFF757575)
    }
}

private val textExt = setOf("txt", "md", "log", "json", "xml", "csv", "ini", "html", "css", "js", "kt", "java", "py", "yml", "yaml", "conf", "sh", "bat", "srt")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: FileViewModel, onGrantAllFiles: () -> Unit) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.upload(uris)
    }

    var dialog by remember { mutableStateOf<Dialog?>(null) }

    vm.editor?.let { EditorScreen(vm); return }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = { TopBar(vm, onNewFolder = { dialog = Dialog.NewFolder }, onNewFile = { dialog = Dialog.NewFile },
            onUpload = { picker.launch(arrayOf("*/*")) }) },
        bottomBar = { BottomBar(vm, onRename = { e -> dialog = Dialog.Rename(e) }, onDelete = { dialog = Dialog.Delete }) },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (vm.backendId == null) HomeScreen(vm, onGrantAllFiles) else BrowserScreen(vm)
        }
    }

    when (val d = dialog) {
        Dialog.NewFolder -> NameDialog("فولدر جديد", "", "إنشاء", { dialog = null }) { vm.newFolder(it); dialog = null }
        Dialog.NewFile -> NameDialog("ملف جديد", "note.txt", "إنشاء", { dialog = null }) { vm.newFile(it); dialog = null }
        is Dialog.Rename -> NameDialog("إعادة تسمية", d.entry.name, "تم", { dialog = null }) { vm.rename(d.entry, it); dialog = null }
        Dialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("حذف ${vm.selection.size} عنصر؟") },
            text = { Text("الحذف نهائي ومفيش سلة محذوفات على الفلاشة.") },
            confirmButton = { TextButton(onClick = { vm.delete(); dialog = null }) { Text("حذف", color = Color(0xFFD32F2F)) } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("إلغاء") } },
        )
        null -> {}
    }

    vm.busy?.let { b ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(b.title) },
            text = {
                Column {
                    Text(b.current, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(12.dp))
                    if (b.total > 0) LinearProgressIndicator(progress = { (b.done.toFloat() / b.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (b.total > 0) Text("${fmtSize(b.done)} / ${fmtSize(b.total)}", fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { vm.cancel() }) { Text("إلغاء") } },
        )
    }
}

sealed interface Dialog {
    data object NewFolder : Dialog
    data object NewFile : Dialog
    data object Delete : Dialog
    data class Rename(val entry: FsEntry) : Dialog
}

@Composable
private fun NameDialog(title: String, initial: String, ok: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, singleLine = true, keyboardOptions = KeyboardOptions.Default) },
        confirmButton = { TextButton(onClick = { onOk(t) }) { Text(ok) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopBar(vm: FileViewModel, onNewFolder: () -> Unit, onNewFile: () -> Unit, onUpload: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    val selecting = vm.selection.isNotEmpty()
    val containerColor = MaterialTheme.colorScheme.background

    when {
        selecting -> TopAppBar(
            title = { Text("${vm.selection.size} متحدد") },
            navigationIcon = { IconButton({ vm.clearSelection() }) { Icon(Icons.Filled.Close, null) } },
            actions = { IconButton({ vm.selectAll() }) { Icon(Icons.Filled.SelectAll, "تحديد الكل") } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = containerColor),
        )
        vm.backendId == null -> TopAppBar(
            title = { Text("ملفاتي", fontSize = 26.sp) },
            actions = { IconButton({ vm.refreshAll() }) { Icon(Icons.Filled.Refresh, "تحديث") } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = containerColor),
        )
        searching -> TopAppBar(
            title = {
                OutlinedTextField(vm.query, { vm.query = it }, singleLine = true, placeholder = { Text("بحث") }, modifier = Modifier.fillMaxWidth())
            },
            navigationIcon = { IconButton({ searching = false; vm.query = "" }) { Icon(Icons.Filled.ArrowBack, null) } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = containerColor),
        )
        else -> TopAppBar(
            title = {
                Column {
                    Text(vm.backend?.title ?: "", fontSize = 18.sp, maxLines = 1)
                    Text(vm.path, fontSize = 12.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            },
            navigationIcon = { IconButton({ vm.back() }) { Icon(Icons.Filled.ArrowBack, null) } },
            actions = {
                IconButton({ searching = true }) { Icon(Icons.Filled.Search, "بحث") }
                IconButton({ sortMenu = true }) { Icon(Icons.Filled.Sort, "ترتيب") }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    SortBy.entries.forEach { s ->
                        DropdownMenuItem(
                            text = { Text(when (s) { SortBy.NAME -> "الاسم"; SortBy.DATE -> "التاريخ"; SortBy.SIZE -> "الحجم"; SortBy.TYPE -> "النوع" }) },
                            onClick = { if (vm.sortBy == s) vm.ascending = !vm.ascending else { vm.sortBy = s; vm.ascending = true }; sortMenu = false },
                            trailingIcon = { if (vm.sortBy == s) Icon(if (vm.ascending) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward, null) },
                        )
                    }
                }
                IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, null) }
                DropdownMenu(menu, { menu = false }) {
                    val canWrite = vm.backend?.writable == true
                    DropdownMenuItem({ Text("فولدر جديد") }, { menu = false; onNewFolder() }, enabled = canWrite,
                        leadingIcon = { Icon(Icons.Filled.CreateNewFolder, null) })
                    DropdownMenuItem({ Text("ملف نصي جديد") }, { menu = false; onNewFile() }, enabled = canWrite,
                        leadingIcon = { Icon(Icons.Filled.NoteAdd, null) })
                    DropdownMenuItem({ Text("رفع ملفات من الموبايل") }, { menu = false; onUpload() }, enabled = canWrite,
                        leadingIcon = { Icon(Icons.Filled.Upload, null) })
                    DropdownMenuItem({ Text(if (vm.showHidden) "إخفاء الملفات المخفية" else "إظهار الملفات المخفية") },
                        { vm.showHidden = !vm.showHidden; menu = false }, leadingIcon = { Icon(Icons.Filled.Visibility, null) })
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = containerColor),
        )
    }
}

@Composable
private fun BottomBar(vm: FileViewModel, onRename: (FsEntry) -> Unit, onDelete: () -> Unit) {
    val sel = vm.entries.filter { it.path in vm.selection }
    val clip = vm.clip
    val writable = vm.backend?.writable == true
    if (sel.isNotEmpty()) {
        NavigationBar(containerColor = Color.White) {
            @Composable fun item(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) =
                NavigationBarItem(false, onClick, { Icon(icon, label) }, label = { Text(label, fontSize = 11.sp) }, enabled = enabled)
            item(Icons.Filled.ContentCopy, "نسخ") { vm.copySelected() }
            item(Icons.Filled.ContentCut, "نقل", writable) { vm.cutSelected() }
            item(Icons.Filled.DriveFileRenameOutline, "تسمية", writable && sel.size == 1) { onRename(sel.first()) }
            item(Icons.Filled.Delete, "حذف", writable) { onDelete() }
        }
    } else if (clip != null && vm.backendId != null) {
        Surface(color = Color.White, tonalElevation = 3.dp) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (clip.cut) Icons.Filled.ContentCut else Icons.Filled.ContentCopy, null)
                Spacer(Modifier.width(8.dp))
                Text("${clip.entries.size} عنصر", Modifier.weight(1f))
                TextButton({ vm.paste() }, enabled = writable) { Text("لصق هنا") }
            }
        }
    }
}

@Composable
private fun HomeScreen(vm: FileViewModel, onGrantAllFiles: () -> Unit) {
    val backends by vm.backends.collectAsState()
    val usb by vm.usbDevices.collectAsState()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (!vm.hub.hasAllFilesAccess()) item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0))) {
                Column(Modifier.padding(16.dp)) {
                    Text("محتاج صلاحية الوصول لكل الملفات", fontSize = 16.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(onGrantAllFiles) { Text("فتح الإعدادات") }
                }
            }
        }
        item { Text("وحدات التخزين", fontSize = 14.sp, color = Color.Gray) }
        items(backends, key = { it.id }) { b -> StorageCard(b) { vm.openBackend(b.id) } }

        item { Text("أجهزة USB", fontSize = 14.sp, color = Color.Gray) }
        if (usb.isEmpty()) item { Text("مفيش جهاز متوصل. وصّل الفلاشة/الهارد بالـOTG.", color = Color.Gray) }
        items(usb, key = { it.deviceName }) { d -> UsbCard(vm, d) }
    }
}

@Composable
private fun StorageCard(b: FsBackend, onClick: () -> Unit) {
    val total = remember(b.id) { runCatching { b.totalBytes }.getOrDefault(0L) }
    val free = runCatching { b.freeBytes }.getOrDefault(0L)
    Card(onClick = onClick, shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (b.id == "internal") Icons.Filled.PhoneAndroid else Icons.Filled.Usb, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(b.title, fontSize = 17.sp)
                if (total > 0) {
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(progress = { ((total - free).toFloat() / total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(4.dp))
                    Text("${fmtSize(total - free)} مستخدم من ${fmtSize(total)}" + if (!b.writable) " • للقراءة فقط" else "", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
    }
}

@Composable
private fun UsbCard(vm: FileViewModel, d: UsbDevice) {
    val mounted = vm.hub.isMounted(d)
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Usb, null, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(d.productName ?: "USB device", fontSize = 16.sp)
                    Text(d.deviceName, fontSize = 11.sp, color = Color.Gray, fontFamily = FontFamily.Monospace)
                }
            }
            Spacer(Modifier.height(8.dp))
            if (mounted) {
                OutlinedButton({ vm.eject(d) }) { Icon(Icons.Filled.Eject, null); Spacer(Modifier.width(6.dp)); Text("إخراج بأمان") }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(vm.readOnlyMount, { vm.readOnlyMount = it })
                    Spacer(Modifier.width(8.dp)); Text("قراءة فقط", fontSize = 13.sp)
                }
                Spacer(Modifier.height(4.dp))
                Button({ vm.mountUsb(d) }) { Text("فتح بدرايفر NTFS") }
                Text("استخدمها لو الفلاشة NTFS ومظهرتش فوق. FAT32/exFAT بيفتحوا لوحدهم.", fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BrowserScreen(vm: FileViewModel) {
    val list = vm.visible
    if (vm.loading && list.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        return
    }
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { Text("المجلد فاضي", color = Color.Gray) }
        return
    }
    Card(Modifier.padding(horizontal = 12.dp).fillMaxSize(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        LazyColumn(Modifier.fillMaxSize()) {
            items(list, key = { it.path }) { e ->
                val selected = e.path in vm.selection
                val (icon, tint) = iconFor(e)
                Row(
                    Modifier.fillMaxWidth()
                        .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                        .combinedClickable(
                            onClick = {
                                when {
                                    vm.selection.isNotEmpty() -> vm.toggle(e)
                                    e.isDir -> vm.navigate(e.path)
                                    e.name.substringAfterLast('.', "").lowercase() in textExt -> vm.openEditor(e)
                                    else -> vm.toggle(e)
                                }
                            },
                            onLongClick = { vm.toggle(e) },
                        )
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (selected) Icon(Icons.Filled.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                    else Icon(icon, null, tint = tint, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            listOf(fmtDate(e.modified), if (e.isDir) "" else fmtSize(e.size)).filter { it.isNotEmpty() }.joinToString("  •  "),
                            fontSize = 12.sp, color = Color.Gray,
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditorScreen(vm: FileViewModel) {
    val ed = vm.editor ?: return
    val writable = vm.backends.collectAsState().value.firstOrNull { it.id == ed.backendId }?.writable == true
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(nameOf(ed.entry.path) + if (ed.dirty) " •" else "", maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = { IconButton({ vm.closeEditor() }) { Icon(Icons.Filled.ArrowBack, null) } },
            actions = { IconButton({ vm.saveEditor() }, enabled = ed.dirty && writable) { Icon(Icons.Filled.Save, "حفظ") } },
        )
    }) { pad ->
        OutlinedTextField(
            value = ed.text, onValueChange = { vm.editText(it) }, readOnly = !writable,
            modifier = Modifier.padding(pad).fillMaxSize().padding(8.dp),
            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
        )
    }
}

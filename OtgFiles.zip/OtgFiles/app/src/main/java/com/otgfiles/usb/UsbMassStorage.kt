package com.otgfiles.usb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Raw byte-addressed block device. */
interface BlockDevice {
    val sizeBytes: Long
    fun read(offset: Long, buf: ByteArray, len: Int): Int
    fun write(offset: Long, buf: ByteArray, len: Int): Int
    fun flush()
}

/**
 * USB Mass Storage, Bulk-Only Transport, SCSI transparent command set.
 * Talks directly to the flash drive / HDD through Android's USB Host API,
 * so it does not depend on the OS mounting the filesystem.
 */
class UsbMassStorage(
    private val manager: UsbManager,
    val device: UsbDevice,
) : BlockDevice {

    private var conn: UsbDeviceConnection? = null
    private lateinit var iface: UsbInterface
    private lateinit var epIn: UsbEndpoint
    private lateinit var epOut: UsbEndpoint
    private var tag = 1
    var blockSize = 512
        private set
    var blockCount = 0L
        private set
    override val sizeBytes: Long get() = blockCount * blockSize
    var label: String = "USB"
        private set

    fun open() {
        var found: UsbInterface? = null
        for (i in 0 until device.interfaceCount) {
            val itf = device.getInterface(i)
            if (itf.interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE &&
                itf.interfaceSubclass == 6 && itf.interfaceProtocol == 80
            ) { found = itf; break }
        }
        iface = found ?: throw IOException("No mass-storage interface")
        for (i in 0 until iface.endpointCount) {
            val ep = iface.getEndpoint(i)
            if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                if (ep.direction == UsbConstants.USB_DIR_IN) epIn = ep else epOut = ep
            }
        }
        val c = manager.openDevice(device) ?: throw IOException("Cannot open USB device")
        if (!c.claimInterface(iface, true)) { c.close(); throw IOException("Cannot claim interface") }
        conn = c

        // Some devices need a few tries before they report ready
        var ready = false
        repeat(10) {
            if (!ready) {
                ready = try { testUnitReady() } catch (e: IOException) { false }
                if (!ready) Thread.sleep(300)
            }
        }
        label = try { inquiry() } catch (e: IOException) { device.productName ?: "USB" }
        readCapacity()
    }

    fun close() {
        conn?.let { it.releaseInterface(iface); it.close() }
        conn = null
    }

    // ---------------- BOT ----------------

    private fun transfer(cdb: ByteArray, dataLen: Int, dirIn: Boolean, data: ByteArray?, dataOff: Int = 0): Int {
        val c = conn ?: throw IOException("Closed")
        val t = tag++
        val cbw = ByteBuffer.allocate(31).order(ByteOrder.LITTLE_ENDIAN)
        cbw.putInt(0x43425355).putInt(t).putInt(dataLen)
        cbw.put(if (dirIn) 0x80.toByte() else 0).put(0).put(cdb.size.toByte())
        cbw.put(cdb)
        if (c.bulkTransfer(epOut, cbw.array(), 31, 5000) != 31) { reset(); throw IOException("CBW failed") }

        var done = 0
        if (dataLen > 0 && data != null) {
            val ep = if (dirIn) epIn else epOut
            while (done < dataLen) {
                val n = minOf(CHUNK, dataLen - done)
                val r = c.bulkTransfer(ep, data, dataOff + done, n, 15000)
                if (r < 0) {
                    c.controlTransfer(0x02, 1, 0, ep.address, null, 0, 1000) // clear halt
                    break
                }
                done += r
            }
        }
        val csw = ByteArray(13)
        var r = c.bulkTransfer(epIn, csw, 13, 10000)
        if (r != 13) {
            c.controlTransfer(0x02, 1, 0, epIn.address, null, 0, 1000)
            r = c.bulkTransfer(epIn, csw, 13, 10000)
        }
        if (r != 13) { reset(); throw IOException("CSW failed") }
        val status = csw[12].toInt()
        if (status != 0) { if (status == 2) reset(); throw IOException("SCSI status $status") }
        return done
    }

    private fun reset() {
        val c = conn ?: return
        c.controlTransfer(0x21, 0xFF, 0, iface.id, null, 0, 1000)
        c.controlTransfer(0x02, 1, 0, epIn.address, null, 0, 1000)
        c.controlTransfer(0x02, 1, 0, epOut.address, null, 0, 1000)
    }

    private fun testUnitReady(): Boolean {
        transfer(ByteArray(6), 0, true, null); return true
    }

    private fun inquiry(): String {
        val cdb = ByteArray(6).also { it[0] = 0x12; it[4] = 36 }
        val buf = ByteArray(36)
        transfer(cdb, 36, true, buf)
        val vendor = String(buf, 8, 8, Charsets.US_ASCII).trim()
        val product = String(buf, 16, 16, Charsets.US_ASCII).trim()
        return "$vendor $product".trim().ifEmpty { "USB" }
    }

    private fun readCapacity() {
        val cdb = ByteArray(10).also { it[0] = 0x25 }
        val buf = ByteArray(8)
        transfer(cdb, 8, true, buf)
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.BIG_ENDIAN)
        val last = bb.int.toLong() and 0xFFFFFFFFL
        blockSize = bb.int
        blockCount = last + 1
        if (last == 0xFFFFFFFFL) {
            val cdb16 = ByteArray(16).also { it[0] = 0x9E.toByte(); it[1] = 0x10; it[13] = 32 }
            val b2 = ByteArray(32)
            transfer(cdb16, 32, true, b2)
            val bb2 = ByteBuffer.wrap(b2).order(ByteOrder.BIG_ENDIAN)
            blockCount = bb2.long + 1
            blockSize = bb2.int
        }
        if (blockSize <= 0) throw IOException("Bad block size")
    }

    private fun cdbRw(write: Boolean, lba: Long, count: Int): ByteArray {
        return if (lba + count < 0x100000000L && count <= 0xFFFF) {
            ByteBuffer.allocate(10).order(ByteOrder.BIG_ENDIAN).apply {
                put(if (write) 0x2A else 0x28); put(0); putInt(lba.toInt()); put(0); putShort(count.toShort()); put(0)
            }.array()
        } else {
            ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN).apply {
                put(if (write) 0x8A.toByte() else 0x88.toByte()); put(0); putLong(lba); putInt(count); put(0); put(0)
            }.array()
        }
    }

    @Synchronized
    private fun rwBlocks(write: Boolean, lba: Long, count: Int, buf: ByteArray, off: Int) {
        var attempt = 0
        while (true) {
            try {
                transfer(cdbRw(write, lba, count), count * blockSize, !write, buf, off)
                return
            } catch (e: IOException) {
                if (++attempt >= 2) throw e
            }
        }
    }

    // ---------------- BlockDevice (byte addressed, unaligned OK) ----------------

    @Synchronized
    override fun read(offset: Long, buf: ByteArray, len: Int): Int {
        if (offset < 0 || offset + len > sizeBytes) throw IOException("Read past end")
        val bs = blockSize.toLong()
        val first = offset / bs
        val last = (offset + len - 1) / bs
        val total = (last - first + 1).toInt()
        var done = 0
        val tmp = ByteArray(MAX_BLOCKS_BYTES)
        var lba = first
        var remaining = total
        var dst = 0
        val head = (offset - first * bs).toInt()
        while (remaining > 0) {
            val n = minOf(remaining, MAX_BLOCKS_BYTES / blockSize)
            rwBlocks(false, lba, n, tmp, 0)
            val srcStart = if (lba == first) head else 0
            val avail = n * blockSize - srcStart
            val copy = minOf(avail, len - dst)
            System.arraycopy(tmp, srcStart, buf, dst, copy)
            dst += copy; done += copy; lba += n; remaining -= n
        }
        return done
    }

    @Synchronized
    override fun write(offset: Long, buf: ByteArray, len: Int): Int {
        if (offset < 0 || offset + len > sizeBytes) throw IOException("Write past end")
        val bs = blockSize
        var pos = offset
        var src = 0
        val tmp = ByteArray(MAX_BLOCKS_BYTES)
        while (src < len) {
            val lba = pos / bs
            val inBlock = (pos % bs).toInt()
            val maxBlocks = MAX_BLOCKS_BYTES / bs
            val want = len - src
            val blocksNeeded = minOf(maxBlocks.toLong(), (inBlock + want + bs - 1) / bs.toLong()).toInt()
            val bytesSpan = blocksNeeded * bs
            val copy = minOf(want, bytesSpan - inBlock)
            if (inBlock != 0 || copy != bytesSpan) {
                // partial blocks at the edges: read-modify-write
                rwBlocks(false, lba, blocksNeeded, tmp, 0)
            }
            System.arraycopy(buf, src, tmp, inBlock, copy)
            rwBlocks(true, lba, blocksNeeded, tmp, 0)
            src += copy; pos += copy
        }
        return len
    }

    override fun flush() {
        try {
            transfer(ByteArray(10).also { it[0] = 0x35 }, 0, true, null) // SYNCHRONIZE CACHE(10)
        } catch (_: IOException) { /* not all devices implement it */ }
    }

    companion object {
        private const val CHUNK = 16384
        private const val MAX_BLOCKS_BYTES = 256 * 1024
    }
}

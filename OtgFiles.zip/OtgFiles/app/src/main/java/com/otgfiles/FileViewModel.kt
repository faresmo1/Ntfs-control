package com.otgfiles

import android.app.Application
import android.hardware.usb.UsbDevice
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.otgfiles.fs.FileOps
import com.otgfiles.fs.FsBackend
import com.otgfiles.fs.FsEntry
import com.otgfiles.fs.Progress
import com.otgfiles.fs.joinPath
import com.otgfiles.fs.parentOf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class SortBy { NAME, DATE, SIZE, TYPE }

data class Clip(val backendId: String, val entries: List<FsEntry>, val cut: Boolean)
data class Busy(val title: String, val current: String, val done: Long, val total: Long)
data class Editor(val backendId: String, val entry: FsEntry, val text: String, val dirty: Boolean = false)

class FileViewModel(app: Application) : AndroidViewModel(app) {
    val hub = StorageHub(app)
    val backends get() = hub.backends
    val usbDevices get() = hub.usbDevices
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 16)

    var backendId by mutableStateOf<String?>(null)   // null = home screen
        private set
    var path by mutableStateOf("/")
        private set
    var entries by mutableStateOf<List<FsEntry>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var selection by mutableStateOf<Set<String>>(emptySet())
        private set
    var sortBy by mutableStateOf(SortBy.NAME)
    var ascending by mutableStateOf(true)
    var showHidden by mutableStateOf(false)
    var query by mutableStateOf("")
    var clip by mutableStateOf<Clip?>(null)
        private set
    var busy by mutableStateOf<Busy?>(null)
        private set
    var editor by mutableStateOf<Editor?>(null)
        private set
    var readOnlyMount by mutableStateOf(false)

    private var job: Job? = null

    val backend: FsBackend? get() = backends.value.firstOrNull { it.id == backendId }

    val visible: List<FsEntry>
        get() {
            var l = entries
            if (!showHidden) l = l.filter { !it.name.startsWith(".") }
            if (query.isNotBlank()) l = l.filter { it.name.contains(query, ignoreCase = true) }
            val cmp: Comparator<FsEntry> = when (sortBy) {
                SortBy.NAME -> compareBy { it.name.lowercase() }
                SortBy.DATE -> compareBy { it.modified }
                SortBy.SIZE -> compareBy { it.size }
                SortBy.TYPE -> compareBy({ it.name.substringAfterLast('.', "").lowercase() }, { it.name.lowercase() })
            }
            val sorted = l.sortedWith(if (ascending) cmp else cmp.reversed())
            return sorted.sortedByDescending { it.isDir }   // folders first, like My Files
        }

    // ---------------- navigation ----------------

    fun openBackend(id: String) { backendId = id; path = "/"; query = ""; selection = emptySet(); load() }
    fun goHome() { backendId = null; path = "/"; entries = emptyList(); selection = emptySet(); query = "" }
    fun navigate(p: String) { path = p; query = ""; selection = emptySet(); load() }

    /** @return true if consumed */
    fun back(): Boolean {
        if (editor != null) { editor = null; return true }
        if (selection.isNotEmpty()) { selection = emptySet(); return true }
        if (backendId == null) return false
        if (path != "/") navigate(parentOf(path)) else goHome()
        return true
    }

    fun load() {
        val b = backend ?: return
        loading = true
        viewModelScope.launch {
            try {
                entries = withContext(Dispatchers.IO) { b.list(path) }
            } catch (e: Exception) { messages.tryEmit("تعذر فتح المجلد: ${e.message}") }
            loading = false
        }
    }

    fun refreshAll() { hub.refresh(); if (backendId != null) load() }

    // ---------------- selection ----------------

    fun toggle(e: FsEntry) { selection = if (e.path in selection) selection - e.path else selection + e.path }
    fun selectAll() { selection = visible.map { it.path }.toSet() }
    fun clearSelection() { selection = emptySet() }
    private fun selected() = entries.filter { it.path in selection }

    // ---------------- operations ----------------

    private fun launchOp(title: String, block: suspend (FsBackend, Progress) -> Unit) {
        val b = backend ?: return
        if (busy != null) { messages.tryEmit("في عملية شغالة"); return }
        job = viewModelScope.launch {
            val p = Progress()
            busy = Busy(title, "", 0, 0)
            val ticker = launch {
                while (true) { busy = Busy(title, p.current, p.doneBytes, p.totalBytes); delay(200) }
            }
            try {
                withContext(Dispatchers.IO) { block(b, p) }
                messages.tryEmit("تم: $title")
            } catch (e: CancellationException) {
                messages.tryEmit("اتلغت العملية")
            } catch (e: Exception) {
                messages.tryEmit("فشل: ${e.message}")
            } finally {
                ticker.cancel(); busy = null; selection = emptySet(); load()
            }
        }
    }

    fun cancel() { job?.cancel() }

    fun delete() {
        val items = selected()
        launchOp("حذف ${items.size} عنصر") { b, p -> items.forEach { p.current = it.name; b.delete(it.path) } }
    }

    fun rename(e: FsEntry, newName: String) {
        val n = newName.trim()
        if (n.isEmpty() || n.contains('/') || n == e.name) return
        launchOp("إعادة تسمية") { b, _ ->
            if (b.stat(joinPath(parentOf(e.path), n)) != null) throw IllegalStateException("الاسم موجود بالفعل")
            b.rename(e.path, joinPath(parentOf(e.path), n))
        }
    }

    fun newFolder(name: String) {
        val n = name.trim(); if (n.isEmpty() || n.contains('/')) return
        val dir = path
        launchOp("فولدر جديد") { b, _ -> b.mkdir(joinPath(dir, n)) }
    }

    fun newFile(name: String) {
        val n = name.trim(); if (n.isEmpty() || n.contains('/')) return
        val dir = path
        launchOp("ملف جديد") { b, _ -> b.createFile(joinPath(dir, n)) }
    }

    fun copySelected() { clip = backendId?.let { Clip(it, selected(), false) }; selection = emptySet() }
    fun cutSelected() { clip = backendId?.let { Clip(it, selected(), true) }; selection = emptySet() }

    fun paste() {
        val c = clip ?: return
        val src = backends.value.firstOrNull { it.id == c.backendId } ?: run { messages.tryEmit("المصدر اتفصل"); clip = null; return }
        val dir = path
        launchOp(if (c.cut) "نقل" else "نسخ") { dst, p ->
            p.totalBytes = c.entries.sumOf { FileOps.sizeOf(src, it) }
            for (e in c.entries) {
                if (c.cut) FileOps.move(src, e, dst, dir, p) else FileOps.copy(src, e, dst, dir, p)
            }
            if (c.cut) clip = null
        }
    }

    /** Upload files picked with the system picker (from anywhere on the phone) into the current folder. */
    fun upload(uris: List<Uri>) {
        val cr = getApplication<Application>().contentResolver
        val dir = path
        launchOp("رفع ${uris.size} ملف") { dst, p ->
            val infos = uris.map { u ->
                var name = u.lastPathSegment ?: "file"; var size = 0L
                cr.query(u, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) }
                        c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 }?.let { size = c.getLong(it) }
                    }
                }
                Triple(u, name, size)
            }
            p.totalBytes = infos.sumOf { it.third }
            for ((u, name, size) in infos) {
                val ins = cr.openInputStream(u) ?: throw IllegalStateException("مش قادر أقرا $name")
                FileOps.copyStreamInto(ins, dst, dir, name, size, p)
            }
        }
    }

    // ---------------- text editor ----------------

    fun openEditor(e: FsEntry) {
        val b = backend ?: return
        if (e.size > 2L * 1024 * 1024) { messages.tryEmit("الملف كبير للتعديل النصي (أقصى 2MB)"); return }
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) { b.openRead(e.path).use { String(it.readBytes(), Charsets.UTF_8) } }
                editor = Editor(b.id, e, text)
            } catch (ex: Exception) { messages.tryEmit("تعذر فتح الملف: ${ex.message}") }
        }
    }

    fun editText(t: String) { editor = editor?.copy(text = t, dirty = true) }
    fun closeEditor() { editor = null }

    fun saveEditor() {
        val ed = editor ?: return
        val b = backends.value.firstOrNull { it.id == ed.backendId } ?: return
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { b.openWrite(ed.entry.path).use { it.write(ed.text.toByteArray(Charsets.UTF_8)) } }
                editor = ed.copy(dirty = false)
                messages.tryEmit("تم الحفظ")
                load()
            } catch (ex: Exception) { messages.tryEmit("فشل الحفظ: ${ex.message}") }
        }
    }

    // ---------------- USB ----------------

    fun mountUsb(d: UsbDevice) {
        hub.readOnlyMount = readOnlyMount
        viewModelScope.launch {
            try { messages.tryEmit(hub.mountNtfs(d)) }
            catch (e: Exception) { messages.tryEmit(e.message ?: "فشل التحميل") }
        }
    }

    fun eject(d: UsbDevice) {
        viewModelScope.launch {
            if (backend?.id?.contains(d.deviceName) == true) goHome()
            hub.eject(d); messages.tryEmit("تم الإخراج بأمان. تقدر تشيل الفلاشة")
        }
    }

    override fun onCleared() { hub.release() }
}

cmake_minimum_required(VERSION 3.22.1)
project(ntfsjni C)

# ntfs-3g sources are downloaded by the CI workflow (or scripts/fetch-ntfs3g.sh) into ./ntfs-3g
set(NTFS3G_DIR ${CMAKE_CURRENT_SOURCE_DIR}/ntfs-3g)
if(NOT EXISTS ${NTFS3G_DIR}/libntfs-3g/volume.c)
    message(FATAL_ERROR "ntfs-3g sources missing. Run scripts/fetch-ntfs3g.sh first.")
endif()

set(LIB ${NTFS3G_DIR}/libntfs-3g)
file(GLOB NTFS_SRC ${LIB}/*.c)
# platform files we don't want on Android
list(FILTER NTFS_SRC EXCLUDE REGEX ".*/win32_io\\.c$")
list(FILTER NTFS_SRC EXCLUDE REGEX ".*/ioctl\\.c$")

add_library(ntfsjni SHARED ntfs_jni.c ${NTFS_SRC})

target_include_directories(ntfsjni PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/compat      # our config.h
    ${NTFS3G_DIR}/include
    ${NTFS3G_DIR}/include/ntfs-3g)

target_compile_definitions(ntfsjni PRIVATE
    HAVE_CONFIG_H
    _FILE_OFFSET_BITS=64
    _GNU_SOURCE)

target_compile_options(ntfsjni PRIVATE -O2 -w)
target_link_libraries(ntfsjni log)
# 16 KB page size support (Android 15+ devices)
target_link_options(ntfsjni PRIVATE -Wl,-z,max-page-size=16384)

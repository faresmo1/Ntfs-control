/* Hand-written config.h for building libntfs-3g with the Android NDK (no autotools). */
#ifndef OTG_NTFS_CONFIG_H
#define OTG_NTFS_CONFIG_H

#define PACKAGE "ntfs-3g"
#define PACKAGE_NAME "ntfs-3g"
#define VERSION "2022.10.3"
#define PACKAGE_VERSION "2022.10.3"
#define EXTERNAL_VERSION "2022.10.3"

#define HAVE_ERRNO_H 1
#define HAVE_FCNTL_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_LIMITS_H 1
#define HAVE_LOCALE_H 1
#define HAVE_STDARG_H 1
#define HAVE_STDDEF_H 1
#define HAVE_STDINT_H 1
#define HAVE_STDIO_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_STRINGS_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_IOCTL_H 1
#define HAVE_SYS_TIME_H 1
#define HAVE_UNISTD_H 1
#define HAVE_TIME_H 1
#define HAVE_CTYPE_H 1
#define HAVE_WCHAR_H 1
#define HAVE_LANGINFO_H 1
#define HAVE_GETTIMEOFDAY 1
#define HAVE_FSYNC 1
#define HAVE_STRSEP 1
#define HAVE_STRDUP 1
#define HAVE_STRNDUP 1
#define HAVE_MEMMOVE 1
#define HAVE_MEMSET 1
#define HAVE_MEMCPY 1
#define HAVE_ATEXIT 1
#define HAVE_VSNPRINTF 1
#define HAVE_SNPRINTF 1
#define HAVE_SETLOCALE 1
#define HAVE_FFS 1
#define HAVE_REALPATH 1
#define HAVE_LINUX_FS_H 1

#define STDC_HEADERS 1
#define HAVE_STRUCT_STAT_ST_ATIM 1
#define HAVE_STRUCT_STAT_ST_ATIMESPEC 0
#define HAVE_STRUCT_STAT_ST_RDEV 1

/* No FUSE, no extended attributes, no POSIX ACLs, no iconv: UTF-8 only */
#undef HAVE_SETXATTR
#undef POSIXACLS
#undef HAVE_ICONV_H

#endif

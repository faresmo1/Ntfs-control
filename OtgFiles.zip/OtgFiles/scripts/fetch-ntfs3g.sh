#!/usr/bin/env bash
# Downloads the ntfs-3g sources (GPL-2.0+) next to the JNI glue. Needs internet.
set -euo pipefail
cd "$(dirname "$0")/../app/src/main/cpp"
rm -rf ntfs-3g
git clone --depth 1 --branch 2022.10.3 https://github.com/tuxera/ntfs-3g.git ntfs-3g
rm -rf ntfs-3g/.git
echo "ntfs-3g fetched."
